import React from "react";

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="bg-green-600 text-white py-12 text-center">
        <h1 className="text-4xl font-bold">Sai Koundinya Lanka</h1>
        <p className="text-lg mt-2">Java | Spring Boot | Angular | Cloud | Full-Stack Developer</p>
      </header>

      <section className="max-w-5xl mx-auto py-12 px-4">
        <h2 className="text-2xl font-semibold text-green-600 border-l-4 pl-3 mb-4 border-green-600">About Me</h2>
        <p className="text-lg">
          Passionate full-stack developer with hands-on experience in Java, Spring Boot,
          Angular, Python, and Cloud platforms including Google Cloud, AWS & Azure.
          Passionate about building scalable apps & delivering intuitive UIs.
        </p>
      </section>

      <section className="max-w-5xl mx-auto px-4">
        <h2 className="text-2xl font-semibold text-green-600 border-l-4 pl-3 mb-6 border-green-600">Skills</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {["Java / Spring Boot", "Angular / JavaScript", "Python / Flask", "GCP / AWS / Azure", "Docker / Kubernetes / Git", "MySQL / PostgreSQL / Oracle"].map((skill) => (
            <div key={skill} className="bg-white p-4 rounded-xl shadow">{skill}</div>
          ))}
        </div>
      </section>

      <section className="max-w-5xl mx-auto py-10 px-4">
        <h2 className="text-2xl font-semibold text-green-600 border-l-4 pl-3 mb-6 border-green-600">Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {title:"Task Manager App", desc:"Spring Boot + Angular + JWT + MySQL deployed on GCP."},
            {title:"Cybersecurity IDS", desc:"Threat detection using Python, ML & Flask UI."},
            {title:"Firebase Notes App", desc:"Notes app using Angular & Firebase Auth."}
          ].map((p) => (
            <div key={p.title} className="bg-white p-4 rounded-xl shadow">
              <h3 className="font-bold text-lg">{p.title}</h3>
              <p>{p.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="text-center py-6">
        <a href="/Sai_Koundinya_Lanka_Google_Resume.docx" download className="bg-green-600 text-white px-6 py-3 rounded-xl shadow hover:bg-green-700">
          Download Resume
        </a>
      </section>

      <footer className="text-center py-6 bg-gray-900 text-white">© 2025 Sai Koundinya Lanka</footer>
    </div>
  );
}
